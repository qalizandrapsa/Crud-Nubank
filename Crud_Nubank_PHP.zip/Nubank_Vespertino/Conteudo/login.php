<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title> Login - Nubank </title>
        <script type="text/javascript" src="../lib/jquery.js"></script>
        <script type="text/javascript" src="../lib/jquery.maskedinput.js"></script>
        <script type="text/javascript" src="../lib/jquery.validate.min.js"></script>
        <script>
            $(document).ready(function(){
               $("#formulario").validate({
                   rules:{
                       cpf:{
                           maxlength: 6,
                            cpf: true,
                        },
                        senha: {
                            required: "",
                            senha: true,
                            equalTo: "#senha",
                        },
                    },
                    messages: {
                        senha: {
                            required: "",
                            senha: "Digite no maximo 6 caracteres",
                            equalTo: "A senha deve ser digitada",
                        }
                    }
                });
            });
        </script>
        <script>
            jQuery(function($) {
                $("#cpf").mask("999.999.999-99");
            });
        </script>
        <style>
            body{
                background-color: #81259d;
            }
            div#login{
                /*border: 1px solid red;*/
                width: 450px;
                height: 550px;
                top: 50%;
                left: 50%;
                margin-top: -275px;
                margin-left: -225px;
                position: absolute;
                background-color: white;
                border-radius:10px;
            }
            img{
                margin-top: 20px;
                margin-left: 20px;
                
            }
            
            h2{
                text-align: center;
                margin-top: 75px;
                font-family: sans-serif;
                font-size: 21px;
                font-weight: 700;
                line-height: 39px;
                color: #222;
            }
            form{
                margin-left: 15%;
                margin-top: 50px;
            }
            label{
                font-size: 16px;
                color: #f27d72;
            }
            input[type='text'], input[type='password']{
                border: none;
                border-bottom: 1px dotted #f27d72;
                width: 300px;
                height: 30px;
            }
            input[type='submit']{
                margin-top: 60px;
                margin-left: 0px;
                width: 300px;
                height: 60px;
                border: 1px solid #81259d;
                background-color: white;
                font-family: "Arial black";
                font-size: 13px;
                font-weight: 700;
                color:#81259d ;
                border-radius: 5px;
                margin-bottom: 20px;
                transition: all 0.5s ease;
            }
            input[type='submit']:hover{
                background-color: #81259d;
                color: white;
                cursor: pointer;
                transition: all 0.5s ease;
            }
            input[type='text']:focus, input[type='password']:focus{
                border: 0;
                outline: 0;
                border-bottom: 1px dotted #8d3dc8;
                font-size: 19px;
                color:#404040;
            }
            a{
                margin-left: 60px;
                font-size: 15px;
                font-family: arial;
                color: #81259d;
                text-decoration: none;
                font-weight: bold;
            }
            a:hover{
                color: black;
                transition: all 0.5s ease;
                /*margin-left: 70px;*/
            }
        </style>
    </head>
    <body>
        <img src="../Imagens/logologin.png">
        
        <div id="login">
            <h2> Faça seu Login </h2>
            <form action="" method="">
                <label> CPF </label><br>
                <input type="text" name="cpf" id="cpf" required=""><br><br>
                <label> Senha </label><br>
                <input type="password" name="cpf" required=""><br><br>
                <input type="submit" value="continuar" required=""><br><br>
                <a href="#"> Esqueci minha senha > </a>
            </form>
        </div>
    </body>
</html>
