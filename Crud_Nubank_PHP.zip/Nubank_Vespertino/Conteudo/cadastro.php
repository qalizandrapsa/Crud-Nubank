<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title> Cadastro - Nubank </title>
        <script type="text/javascript" src='../lib/jquery.js'></script>
        <script type="text/javascript" src='../lib/jquery.maskedinput.js'></script>
        <script type="text/javascript" src="../lib/jquery.validate.min.js"></script>
        <script>
            $(document).ready(function(){
                $("#formulario").validate({
                    rules:{
                        nome:{
                            minlength: 2,
                        },
                        cpf: {
                            cpf: true,
                        },
                        email: {
                            required: true,
                            email: true,
                        },
                        confemail: {
                            required: true,
                            email: true,
                            equalTo: "#email",
                        }
                    },
                    messages: {
                        nome: {
                            minlength: "Digite ao menos 2 caracteres",
                        },
                        email: {
                            required: "",
                            email: "Por favor digite um email válido",
                        },
                        confemail: {
                            required: "",
                            confemail: "Por favor digite um email válido",
                            equalTo: "Os emails devem ser iguais",
                        }
                    }
                });
            });
        </script>
        <script>
            jQuery(function($){
               $("#cpf").mask("999.999.999-99");  
            });
        </script>
        <style type="text/css">
            body{
                background-color: #81259d;
            }
            div#login{
                /*border: 1px solid red;*/
                width: 450px;
                height: 640px;
                top: 48%;
                left: 50%;
                margin-top: -300px;
                margin-left: -225px;
                position: absolute;
                background-color: white;
                border-radius:10px;
            }
            img{
                margin-top: 20px;
                margin-left: 20px;
            }
            h2{
                text-align: center;
                margin-top: 20px;
                font-family: sans-serif;
                font-size: 28px;
                font-weight: 700;
                color: #81259d;
            }
            form{
                margin-left: 15%;
                margin-top: 50px;
            }
            label{
                font-size: 16px;
                color: #f27d72;
            }
            input[type='text'], input[type='password']{
                border: none;
                border-bottom: 1px dotted #f27d72;
                width: 300px;
                height: 30px;
                font-size: 19px;
                color:#404040;
            }
            input[type='submit']{
                margin-top: 60px;
                margin-left: 0px;
                width: 300px;
                height: 60px;
                border: 1px solid #81259d;
                background-color: white;
                font-family: "Arial black";
                font-size: 13px;
                font-weight: 700;
                color:#81259d ;
                border-radius: 5px;
                margin-bottom: 20px;
                transition: all 0.5s ease;
            }
            input[type='submit']:hover{
                background-color: #81259d;
                color: white;
                cursor: pointer;
                transition: all 0.5s ease;
            }
            input[type='text']:focus, input[type='password']:focus{
                border: 0;
                outline: 0;
                border-bottom: 1px dotted #8d3dc8;
                font-size: 19px;
                color:#f59172;
            }
            a{
                color: #404040;
                font-size: 16px;
                text-decoration: none;
                font-weight: 700;
            }
            .error{
                color:red;
                font-size: 13px;
                display: block;
                height: 0px;
            }
        </style>
    </head>
    <body>
        <img src="../Imagens/logologin.png">
        
        <div id="login">
            <h2> Complete abaixo para<br> pedir sua NuConta e<br> seu cartão de crédito </h2>
            <form action="" method="" id="formulario">
                <label> Nome completo </label><br>
                <input type="text" name="nome"  required=""><br><br>
                <label> CPF </label><br>
                <input type="text" name="cpf" id="cpf" required=""><br><br>
                <label> Email </label><br>
                <input type="text" name="email" id="email" required=""><br><br>
                <label> Confirmação de Email </label><br>
                <input type="text" name="confemail" id="confemail" required=""><br><br>
                <input type="checkbox" name="políticas"><a>Li e concordo com a política de privacidade.</a>
                <input type="submit" value="QUERO SER NUBANK" required="">
            </form>
        </div>
    </body>
</html>
