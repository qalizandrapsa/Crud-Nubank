<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title> Nubank - ETC </title>
        <link rel="stylesheet" type="text/css" href="Estilos/estilo_layout.css">
        <link rel="stylesheet" type="text/css" href="Estilos/estilo_menu.css">
    </head>
    <body>
        <div id="menu">
            <img src="Imagens/logonubank.png">
            <ul>
                <li><a href="#" style="color:#8c09bf">Início</a></li>
                <li><a href="#">NuConta</a></li>
                <li><a href="#">Cartão de Crédito</a></li>
                <li><a href="#">Rewards</a></li>
                <li><a href="#">Emprestimos</a></li>
                <li><a href="#">Sobre nós</a></li>
                <li><a href="#">Carreiras</a></li>
            </ul>
           
            <div id="Quero"><a href="Conteudo/cadastro.php">Quero ser Nubank</a></div>
            <div id="Login"><a href="Conteudo/login.php" target="_blank">Login</a></div>
        </div>
        <div id="conteudo1">
            <div id="teste"></div>
        </div>
        <div id="conteudo2">
            <div id="boxconteudo2">
                <p>
                    <label class="titulo">NuConta</label><br>
                
                
                Nossa conta digital.<br>
                Tudo que uma conta<br>
                tem, menos o que<br>
                não precisa.<br>
                </p>
               
             
                    <a class="link" href="#">Conheça o roxinho com função débito.</a>
               
            </div>
            <img src="Imagens/nuconta-inclined-device@3x.png">
        </div>
        <div id="conteudo3"></div>
        <div id="conteudo4"></div>
        <div id="conteudo5"></div>
        <div id="conteudo6"></div>
        <div id="conteudo7"></div>
        <div id="conteudo8"></div>
        <div id="conteudo9"></div>
    </body>
</html>
